import { useEffect } from "react"

export default function About()
{
    useEffect(()=>{
        window.runSlide()
    },[])
    return 		<div id="fh5co-main">
    <div className="fh5co-narrow-content">
        <div className="row row-bottom-padded-md">
            <div className="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                <img className="img-responsive" src="images/img_bg_1.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"/>
            </div>
            <div className="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                <h2 className="fh5co-heading">About Company</h2>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Quisque sit amet efficitur nih. Interdum et malesuada fames ac ante ipsum primis in faucibus interda et malesuada parturient.</p>
                <p>Quisque sit amet efficitur nih. Interdum et malesuada fames ac ante ipsum primis in faucibus interda et malesuada parturient.</p>
            </div>
        </div>
    </div>

    <div className="fh5co-narrow-content">
            <h2 className="fh5co-heading animate-box" data-animate-effect="fadeInLeft">Our Services</h2>
            <div className="row">
                <div className="col-md-6">
                    <div className="fh5co-feature animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-settings"></i>
                        </div>
                        <div className="fh5co-text">
                            <h3>Strategy</h3>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="fh5co-feature animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-search4"></i>
                        </div>
                        <div className="fh5co-text">
                            <h3>Explore</h3>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        </div>
                    </div>
                </div>

                <div className="col-md-6">
                    <div className="fh5co-feature animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-paperplane"></i>
                        </div>
                        <div className="fh5co-text">
                            <h3>Direction</h3>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="fh5co-feature animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-params"></i>
                        </div>
                        <div className="fh5co-text">
                            <h3>Expertise</h3>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <div className="fh5co-narrow-content">
        <div className="row">
            <div className="col-md-4 animate-box" data-animate-effect="fadeInLeft">
                <h1 className="fh5co-heading-colored">Get in touch</h1>
            </div>
        </div>
        <div className="row">
            <div className="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <p className="fh5co-lead">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <p><a href="#" className="btn btn-primary">Learn More</a></p>
            </div>
            
        </div>
    </div>
</div>
}