import { Link } from "react-router-dom";

export default function SideBar()
{
    return <aside id="fh5co-aside" role="complementary" className="border js-fullheight">

        <h1 id="fh5co-logo"><a href="index.html">Marble</a></h1>
        <nav id="fh5co-main-menu" role="navigation">
            <ul>
                <li className="fh5co-active">
                    <Link to="/"> Home </Link>
                </li>
                <li className="fh5co-active">
                    <Link to="/about"> About </Link>
                </li>
                <li className="fh5co-active">
                    <Link to="/contact"> Contact </Link>
                </li>
            </ul>
        </nav>
    </aside>
}