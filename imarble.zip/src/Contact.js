import { useEffect } from "react"

export default function Contact()
{
    useEffect(()=>{
        window.runSlide()
    },[])
    return 	<div id="fh5co-main">
    <div className="fh5co-more-contact">
        <div className="fh5co-narrow-content">
            <div className="row">
                <div className="col-md-4">
                    <div className="fh5co-feature fh5co-feature-sm animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-globe"></i>
                        </div>
                        <div className="fh5co-text">
                            <p><a href="#">info@domain.com</a></p>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="fh5co-feature fh5co-feature-sm animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-map"></i>
                        </div>
                        <div className="fh5co-text">
                            <p>198 West 21th Street, Suite 721 New York NY 10016</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="fh5co-feature fh5co-feature-sm animate-box" data-animate-effect="fadeInLeft">
                        <div className="fh5co-icon">
                            <i className="icon-phone"></i>
                        </div>
                        <div className="fh5co-text">
                            <p><a href="tel://">+123 456 7890</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div className="fh5co-narrow-content animate-box" data-animate-effect="fadeInLeft">
        
        <div className="row">
            <div className="col-md-4">
                <h2>Get In Touch</h2>
            </div>
        </div>
        <form action="">
            <div className="row">
                <div className="col-md-12">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="form-group">
                                <input type="text" className="form-control" placeholder="Name"/>
                            </div>
                            <div className="form-group">
                                <input type="text" className="form-control" placeholder="Email"/>
                            </div>
                            <div className="form-group">
                                <input type="text" className="form-control" placeholder="Phone"/>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="form-group">
                                <textarea name="" id="message" cols="30" rows="7" className="form-control" placeholder="Message"></textarea>
                            </div>
                            <div className="form-group">
                                <input type="submit" className="btn btn-primary btn-md" value="Send Message"/>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </form>
    </div>
</div>	
}